#include<stdio.h>

int main(void){
    printf("%d", 5/2);
    return 0;
}